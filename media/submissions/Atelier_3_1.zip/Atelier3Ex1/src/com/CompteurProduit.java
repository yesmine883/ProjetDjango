package com;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class CompteurProduit {
    // Create a Counting Map
    // Create a Name Mapping Map

    public static void main(String[] args) {

        // List of part data
        String[] code = new String[]{"1S01", "1S01", "1S01", "1S01", "1S01", "1S02", "1S02", "1S02", "1H01", "1H01", "1S02", "1S01", "1S01", "1H01", "1H01", "1H01", "1S02", "1S02", "1M02", "1M02", "1M02"};

        // Create Product Name Part Number map
        Map<String, String> NomProduits = new TreeMap<>();
        NomProduits.put("Polo bleu", "1S01");
        NomProduits.put("Polo noir", "1S02");
        NomProduits.put("Cap rouge", "1H01");
        NomProduits.put("Pantalon gris   ", "1M02");

        // compter et traiter les données
    }

    public CompteurProduit(Map productNames) {
        // Entrer Votre Code Ici
    }

    public void processList(String[] list) {
        // Entrer Votre Code Ici
    }

    public void afficherReport() {
        // Entrer Votre Code Ici
    }
}
