package com;

import java.util.Comparator;

public class TrierChemiseParDesc implements Comparator<Chemise> {

    public int compare(Chemise s1, Chemise s2) {
        // Ecrire Votre Code Ici
        return 0;
    }
}
