package com;

public interface InventaireNombre {

    public long getCpt();

    public void ajouterItems(long count);

    public void supprimerItems(long count);
}
