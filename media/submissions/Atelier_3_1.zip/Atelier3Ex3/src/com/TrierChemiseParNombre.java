package com;

import java.util.Comparator;

public class TrierChemiseParNombre implements Comparator<Chemise> {

    public int compare(Chemise s1, Chemise s2) {
        // Ecrire Votre code Ici
        return 0;

    }
}
