package com;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TestNombre {

    public static void main(String[] args) {
        
        Chemise chemise = null;

        // créer les élément(chemise) à compter
        Map<String, Chemise> polos = new HashMap<>(10);
        polos.put("P001", new Chemise("P001", "Bleu Polo Chemise", "Bleu", "L"));
        polos.put("P002", new Chemise("P002", "Blanche Polo Chemise", "Blanche", "M"));
        polos.put("P003", new Chemise("P003", "Marron Polo Chemise", "Marron", "XL"));
        polos.put("P004", new Chemise("P004", "Rouge Polo Chemise", "Rouge", "S"));

        // Transactions
        List<Transaction> transactions = new ArrayList<>(20);
        transactions.add(Transaction.creerTransaction("P001", "Achat", 30));
        transactions.add(Transaction.creerTransaction("P002", "Achat", 20));
        transactions.add(Transaction.creerTransaction("P003", "Achat", 20));
        transactions.add(Transaction.creerTransaction("P004", "Achat", 20));
        transactions.add(Transaction.creerTransaction("P001", "Vente", 1));
        transactions.add(Transaction.creerTransaction("P001", "Vente", 2));
        transactions.add(Transaction.creerTransaction("P002", "Vente", 5));
        transactions.add(Transaction.creerTransaction("P002", "Vente", 1));
        transactions.add(Transaction.creerTransaction("P002", "Vente", 2));
        transactions.add(Transaction.creerTransaction("P002", "Vente", 2));
        transactions.add(Transaction.creerTransaction("P002", "Achat", 5));
        transactions.add(Transaction.creerTransaction("P001", "Vente", 3));
        transactions.add(Transaction.creerTransaction("P003", "Vente", 2));
        transactions.add(Transaction.creerTransaction("P003", "Achat", 5));
        transactions.add(Transaction.creerTransaction("P003", "Vente", 3));
        transactions.add(Transaction.creerTransaction("P004", "Vente", 2));
        transactions.add(Transaction.creerTransaction("P004", "Achat", 5));
        transactions.add(Transaction.creerTransaction("P004", "Vente", 4));

        // compter chemise

        // Convertir en liste

        // Init Comparators

        // afficher résultat - trié par Description

        // afficher Résultat - trié par nombre

    }
}
