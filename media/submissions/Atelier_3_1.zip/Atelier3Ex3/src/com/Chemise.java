package com;

public class Chemise implements InventaireNombre {

    private String id = "";
    private String description = "";
    private String couleur = "";
    private String taille = "";
    private long cpt = 0;

    private Chemise() {
    }

    ;

    public Chemise(String id, String description, String couleur, String taille) {
        this.id = id;
        this.description = description;
        this.couleur = couleur;
        this.taille = taille;
    }

    public String getId() {
        return this.id;
    }

    public String getDescription() {
        return description;
    }

    public String getCouleur() {
        return couleur;
    }

    public String getTaille() {
        return taille;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(256);
        sb.append("Chemise ID: ").append(this.getId()).append("\n");
        sb.append("Description: ").append(this.getDescription()).append("\n");
        sb.append("Couleur: ").append(this.getCouleur()).append("\n");
        sb.append("Taille: ").append(this.getTaille()).append("\n");
        sb.append("Inventaire: ").append(this.getCpt()).append("\n");

        return sb.toString();
    }

    @Override
    public long getCpt() {
        return cpt;
    }

    @Override
    public void ajouterItems(long cpt) {
        this.cpt = this.cpt + cpt;
    }

    @Override
    public void supprimerItems(long cpt) {
        if ((this.cpt - cpt) > 0) {
            this.cpt = this.cpt - cpt;
        } else {
            System.out.println("Negative inventory number error.");
        }
    }
}