package com;

public class Transaction {

    private String produitID = "";
    private String transactionType = "";
    private long cpt = 0;

    private Transaction() {
    }

    private Transaction(String produitID, String transactionType, long cpt) {
        this.produitID = produitID;
        this.transactionType = transactionType;
        this.cpt = cpt;
    }

    public static Transaction creerTransaction(String produitID, String transactionType, long cpt) {
        Transaction newTransaction = new Transaction(produitID, transactionType,
                cpt);
        return newTransaction;
    }

    public String getProduitID() {
        return this.produitID;
    }

    public String getTransactionType() {
        return this.transactionType;
    }

    public long getCpt() {
        return this.cpt;
    }
}
