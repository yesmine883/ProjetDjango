package com;

import java.util.ArrayDeque;
import java.util.Deque;

public class ParenCoincide {

    private Deque<Character> file = new ArrayDeque<>();
    private char[] curLine;

    public boolean traiterLine(String line) {
        // Ecrire votre code ici
        return true;
    }

    public void traiterTableauExpression(String[] lignes) {
        int cpt = 0;
        for (String ligne : lignes) {
            if (this.traiterLine(ligne)) {
                System.out.println("Ligne " + cpt + " est valide");
            } else {
                System.out.println("Ligne " + cpt + " est invalide");
            }
            cpt++;
        }
    }

    public static void main(String[] args) {
        ParenCoincide pm = new ParenCoincide();
        String[] expressions = new String[4];

        expressions[0] = "if ((a == b) && (x != y));";
        expressions[1] = "if ((a == b) && (x != y)));";
        expressions[2] = "if ((nom.quals(nouveauNom) && (prenom.equals(nouveauPrenom));";
        expressions[3] = "if ((nom.equals(nouveauNom) && (prenom.equals(nouveauPrenom))));";

        pm.traiterTableauExpression(expressions);
    }
}
